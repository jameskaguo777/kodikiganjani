<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IncomeTaxReturn extends Model
{
    //
    protected $fillable = [ 'post' ];
}
