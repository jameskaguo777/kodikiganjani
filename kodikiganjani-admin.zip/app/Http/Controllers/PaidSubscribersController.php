<?php

namespace App\Http\Controllers;

use App\PaidSubscriber;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use App\PaymentConfiguration;
use App\Subscription;
use App\Vushacallback;
use App\User;
use Illuminate\Http\Request;

class PaidSubscribersController extends Controller
{
    //

    
}
