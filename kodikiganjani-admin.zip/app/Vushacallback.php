<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vushacallback extends Model
{
    //
    protected $fillable = [ 'form' ];
}
